const {read}=require('../../agent/experiments/real-replica.cjs');
const {serve,listening}=require('../../agent/experiments/real-replica-eval.cjs');
async function main(){const root='.runtime/real-replica-v1',capture=read(root+'/capture.json');
 for(const [i,institution]of ['busan','daejeon'].entries()){const s=serve(root,capture,institution,19110+i,'replicas/'+institution+'-401');await listening(s);console.log('Local frozen replica: http://127.0.0.1:'+(19110+i));}
}
main().catch(e=>{console.error(e);process.exitCode=1});
