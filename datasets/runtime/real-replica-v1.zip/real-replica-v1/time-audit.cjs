const assert=require('node:assert/strict'),path=require('node:path');
const {read,save,hash}=require('../../agent/experiments/real-replica.cjs');
const {canonical}=require('../../agent/src/core/collect.cjs');
const root='.runtime/real-replica-v1',rows=read(root+'/rows.json'),runs=read(root+'/runs.json'),catalog=read(root+'/replica-catalog.json'),capture=read(root+'/capture.json');
const before=hash(rows.map(({timeReach,...r})=>r)),datasets={};let corrected=0;
for(const row of rows){if(row.invalid)continue;const site=catalog.find(s=>s.id===row.site),data=datasets[site.id]??=read(root+'/replicas/'+site.id+'.json'),run=runs.find(r=>r.site===row.site&&r.entry===row.entry&&r.mode===row.mode&&r.seed===row.seed&&r.boundary===row.boundary),ads=data.labels.filter(l=>l.is_ad),times=[];let accumulated=0;
 for(const url of run.visited){if(data.pages[url].boundary)break;const u=new URL(url),original=canonical(new URL(u.pathname+u.search,site.source).href),p=capture.pages[original];assert(p,'No measured collection for '+original);accumulated+=p.elapsed_ms;times.push({url,ms:accumulated});}
 const complete=run.visited.length===Object.keys(run.discovered).length;
 row.timeReach=Object.fromEntries([30000,60000].map(ms=>[ms,{valid:accumulated>=ms||(complete&&times.length===run.visited.length),observed_ms:accumulated,reached:ads.filter(l=>times.some(t=>t.ms<=ms&&t.url===l.url)).length}]));assert(accumulated>0);corrected++;
}
assert.equal(hash(rows.map(({timeReach,...r})=>r)),before,'No reach or loss score may change');
save(root,'rows-audited.json',rows);save(root,'time-audit.json',{pass:true,corrected_rows:corrected,non_time_hash:before,reason:'URL.host setter retained the local port when restoring the remote origin. Recomputed stored-time proxies from URL pathname+search with the captured source origin.',original:'rows.json',corrected:'rows-audited.json',navigation_changed:false});console.log(JSON.stringify({pass:true,corrected_rows:corrected}));
