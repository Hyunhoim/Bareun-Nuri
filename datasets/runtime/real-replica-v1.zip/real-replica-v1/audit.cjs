const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const {read,save,modes}=require('../../agent/experiments/real-replica.cjs');
const {canonical,inScope}=require('../../agent/src/core/collect.cjs'),{run}=require('../../agent/src/core/scan.cjs');
const {scheduler,walk}=require('../../agent/experiments/frontier-balanced.cjs');
const root='.runtime/real-replica-v1';
async function main(){
 const rows=read(path.join(root,'rows.json')),runs=read(path.join(root,'runs.json')),catalog=read(path.join(root,'replica-catalog.json')),checks=[];let counted=0;
 for(const site of catalog){const data=read(path.join(root,'replicas/'+site.id+'.json')),ads=data.labels.filter(l=>l.is_ad),packets=data.pages;
  assert.equal(new Set(ads.map(l=>l.url+'\n'+l.selector)).size,ads.length);assert.equal(ads.length,24);
  for(const row of rows.filter(r=>r.site===site.id&&!r.invalid)){
   const r=runs.find(r=>r.site===row.site&&r.entry===row.entry&&r.seed===row.seed&&r.mode===row.mode&&r.boundary===row.boundary),b=runs.find(r=>r.site===row.site&&r.entry===row.entry&&r.seed===row.seed&&r.mode==='fifo'&&r.boundary===row.boundary);
   const entry=data.entries.find(e=>e.id===row.entry).url,visited=r.visited.slice(0,row.budget),seen=new Set(visited),base=new Set(b.visited.slice(0,row.budget)),discovered=new Set([canonical(entry)]);
   for(const u of visited)for(const l of packets[u].profile?.links||[])if(inScope(l.url,new URL(entry),'/')&&(row.boundary==='charged'||packets[canonical(l.url)]?.status===200))discovered.add(canonical(l.url));
   assert.equal(ads.filter(l=>seen.has(l.url)).length,row.reached);assert.deepEqual(ads.filter(l=>base.has(l.url)&&!seen.has(l.url)).map(l=>l.selector),row.lost);
   assert.equal(ads.filter(l=>!seen.has(l.url)&&discovered.has(l.url)).length,row.waiting);assert.equal(ads.filter(l=>!discovered.has(l.url)).length,row.undiscovered);counted++;
  }
  if(site.placement!==401)continue;
  for(const entry of data.entries)for(const mode of modes){
   const dir=path.join(root,'core-checkpoints',entry.id+'-'+mode);assert(!fs.existsSync(dir),'Do not reuse completed core audit');const accesses=[];
   const opts={dir,entry:entry.url,scope:'/',mode,scheduler:scheduler(mode),identity:{provider:'none',version:'replica-1'},createJudge:()=>({calls:[],decide:()=>{throw Error('No LLM calls authorized by this offline audit')}}),
    readPage:async url=>{const u=canonical(url);accesses.push(u);const p=packets[u];assert(p);if(p.status!==200)throw Error(p.boundary?'uncollected_boundary':'recorded_collection_failure');return {pages:[{url:u,readiness:{settled:true},navigation:{links:p.profile.links,profile:p.profile}}],candidates:[],collection_issues:[]};}};
   const a=await run({...opts,limits:{pages:10,calls:1,seconds:120}});assert.equal(a.reason,'page_budget');
   const b=await run({...opts,limits:{pages:20,calls:1,seconds:120}});assert.equal(b.reason,'page_budget');
   const expected=runs.find(r=>r.site===site.id&&r.entry===entry.id&&r.mode===mode&&r.seed===0&&r.boundary==='charged').visited.slice(0,20);
   assert.deepEqual(accesses,expected);assert.deepEqual(b.attempts,expected);assert.equal(new Set(accesses).size,accesses.length);assert.equal(b.calls,0);
   checks.push({site:site.id,entry:entry.id,mode,attempts:accesses.length,failed:b.issues.length,resume:true});
  }
 }
 const result={pass:true,recounted_rows:counted,core_checks:checks,api_calls:0};save(root,'independent-audit.json',result);console.log(JSON.stringify({pass:true,rows:counted,core_checks:checks.length}));
}
main().catch(e=>{console.error(e);process.exitCode=1});
