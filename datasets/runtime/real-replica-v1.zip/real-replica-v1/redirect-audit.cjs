const assert=require('node:assert/strict'),path=require('node:path');
const {read,save,modes}=require('../../agent/experiments/real-replica.cjs'),{canonical}=require('../../agent/src/core/collect.cjs');
const {run}=require('../../agent/src/core/scan.cjs'),{scheduler}=require('../../agent/experiments/frontier-balanced.cjs');
const root='.runtime/real-replica-v1';
async function main(){const capture=read(root+'/capture.json'),byActual={};for(const p of Object.values(capture.pages))if(p.status===200)byActual[canonical(p.actual)]??=p;
 const checks=[];for(const entry of capture.entries)for(const mode of modes){const common={entry:entry.url,scope:'/',mode,scheduler:scheduler(mode),identity:{provider:'none',version:'real-redirect-1'},createJudge:()=>({calls:[],decide:()=>{throw Error('No semantic calls')}}),
  readPage:async u=>{const p=capture.pages[canonical(u)]||byActual[canonical(u)];if(!p)throw Error('uncollected_boundary');if(p.status!==200)throw Error('recorded_failure');return {pages:[{url:p.actual,readiness:{settled:true},navigation:{links:p.packet.profile.links,profile:p.packet.profile}}],candidates:[],collection_issues:[]};}};
 const dir=path.join(root,'redirect-checkpoints',entry.id+'-'+mode),whole=await run({...common,dir:dir+'-whole',limits:{pages:20,calls:1,seconds:120}});
 await run({...common,dir,limits:{pages:10,calls:1,seconds:120}});const resumed=await run({...common,dir,limits:{pages:20,calls:1,seconds:120}});
 assert.equal(whole.status,'partial');assert.deepEqual(resumed.attempts,whole.attempts);assert.deepEqual(resumed.pages,whole.pages);assert.equal(new Set(resumed.pages.map(p=>canonical(p.url))).size,resumed.pages.length);assert.equal(resumed.calls,0);
 const redirects=resumed.attempts.filter(u=>capture.pages[u]?.status===200&&canonical(capture.pages[u].actual)!==canonical(u)).length;
 checks.push({entry:entry.id,mode,attempts:resumed.attempts.length,unique_final_pages:resumed.pages.length,redirect_attempts:redirects,issues:resumed.issues.length,resume:true});
 }save(root,'redirect-audit.json',{pass:true,checks,api_calls:0,note:'Saved original URLs/final URLs replayed through operational core; unknown pages fail explicitly, no remote requests.'});console.log(JSON.stringify({pass:true,conditions:checks.length,redirects:checks.reduce((n,c)=>n+c.redirect_attempts,0)}));}
main().catch(e=>{console.error(e);process.exitCode=1});
