const fs=require('node:fs'),path=require('node:path');
const {read,save,hash,modes}=require('../../agent/experiments/real-replica.cjs');
const root='.runtime/real-replica-v1',capture=read(path.join(root,'capture.json')),summary=read(path.join(root,'summary.json')),rows=read(path.join(root,'rows-audited.json')).filter(r=>!r.invalid),catalog=read(path.join(root,'replica-catalog.json')),validation=read(path.join(root,'replica-validation.json')),collection=read(path.join(root,'collector-checks.json')),audit=read(path.join(root,'independent-audit.json'));
require('node:assert/strict').equal(summary.adoption,'retain_fifo','End-to-end adoption gate required before writing a decision');
const mean=a=>a.reduce((s,n)=>s+n,0)/a.length,pct=x=>(100*x).toFixed(2)+'%',sec=x=>(x/1000).toFixed(2),names={fifo:'FIFO','context-bandit':'문맥 Bandit','template-fifo':'URL 구조별 순환 FIFO'},pages=Object.values(capture.pages),ok=pages.filter(p=>p.status===200);
const live=capture.entries.map(e=>{const ps=pages.filter(p=>new URL(p.url).origin===new URL(e.url).origin);return {entry:e.id,url:e.url,success:ps.filter(p=>p.status===200).length};});
const bodyGroups={};for(const p of ok){const evidence=read(path.join(root,'evidence',p.id+'.json'));p.fulltext=hash(evidence.candidates.map(c=>c.raw_text));p.frame_candidates=evidence.candidates.filter(c=>c.frame_urls.length).length;p.frame_issues=evidence.collection_issues.filter(i=>/frame/.test(i.reason));(bodyGroups[p.packet.profile.fingerprint]??=[]).push(p);}
const collisionGroups=Object.values(bodyGroups).filter(a=>a.length>1&&new Set(a.map(p=>p.fulltext)).size>1);
const diagnostics={pages:pages.length,success:ok.length,failures:pages.filter(p=>p.status!==200),candidates:ok.reduce((n,p)=>n+p.candidates,0),long_candidates:ok.reduce((n,p)=>n+p.long_candidates,0),js_links:ok.reduce((n,p)=>n+p.diagnostic.js_links,0),fragment_links:ok.reduce((n,p)=>n+p.diagnostic.fragment_links,0),handler_links:ok.reduce((n,p)=>n+p.diagnostic.handler_links,0),frames:ok.reduce((n,p)=>n+p.diagnostic.frames.length,0),unsettled:ok.filter(p=>!p.readiness.settled).length,profile_parity:ok.every(p=>p.profile_parity),blocked_requests:ok.reduce((n,p)=>n+p.blocked.length,0),profile_collision_groups:collisionGroups.map(a=>({pages:a.length,distinct_text:new Set(a.map(p=>p.fulltext)).size,urls:a.map(p=>p.url)}))};
const {canonical}=require('../../agent/src/core/collect.cjs');diagnostics.redirects=ok.filter(p=>canonical(p.url)!==canonical(p.actual)).map(p=>({requested:p.url,actual:p.actual}));
const phases={};for(const e of capture.events)for(const [key,value]of Object.entries(e.phases_ms||{}))phases[key]=(phases[key]||0)+value;
const liveRows=capture.runs.filter(r=>r.state).map(r=>{const a=r.state.attempts.map(u=>capture.pages[u]);return {entry:r.entry,mode:r.mode,attempts:a.length,success:a.filter(p=>p.status===200).length,detail:a.filter(p=>p.packet.profile?.detail).length,candidates:a.reduce((n,p)=>n+(p.candidates||0),0),snapshot_ms:a.reduce((n,p)=>n+p.elapsed_ms,0),pending:r.state.pending.length};});
save(root,'live-diagnostics.json',{...diagnostics,phases_ms:phases,live_rows:liveRows});
const groupRows=[];for(const mode of modes)for(const key of [...new Set(rows.flatMap(r=>Object.keys(r.groups)))]){const a=rows.filter(r=>r.mode===mode&&r.budget===20&&r.boundary==='charged'&&r.groups[key]);const total=a.reduce((n,r)=>n+r.groups[key].total,0),hit=a.reduce((n,r)=>n+r.groups[key].reached,0);groupRows.push({mode,key,total,reached:hit,recall:hit/total,lost:a.reduce((n,r)=>n+r.groups[key].lost,0)});}
save(root,'group-summary.json',groupRows);
const table=(headers,rs)=>'| '+headers.join(' | ')+' |\n| '+headers.map(()=>'---').join(' | ')+' |\n'+rs.map(r=>'| '+r.join(' | ')+' |').join('\n');
const aggregateTable=boundary=>table(['정책','@10','@20','@20 FIFO 손실 실행','@20 평균 경계 방문'],modes.map(mode=>{const a=summary.aggregate.find(r=>r.boundary===boundary&&r.mode===mode&&r.budget===10),b=summary.aggregate.find(r=>r.boundary===boundary&&r.mode===mode&&r.budget===20);return [names[mode],pct(a.mean),pct(b.mean),b.lost_runs+'/'+b.n,b.mean_boundary.toFixed(2)];}));
const perEntry=[];for(const entry of capture.entries)for(const mode of modes){const a=rows.filter(r=>r.entry===entry.id&&r.mode===mode&&r.budget===20&&r.boundary==='charged');perEntry.push([entry.id,names[mode],pct(mean(a.map(r=>r.recall))),pct(Math.min(...a.map(r=>r.recall))),pct(mean(summary.perCell.filter(r=>r.entry===entry.id&&r.mode===mode&&r.budget===20).map(r=>r.sd))),a.filter(r=>r.lost.length).length+'/'+a.length]);}
const timeRows=[];for(const ms of [30000,60000])for(const mode of modes){const a=rows.filter(r=>r.mode===mode&&r.boundary==='charged'&&r.budget===20),v=a.filter(r=>r.timeReach[ms].valid);timeRows.push([ms/1000+'초',names[mode],v.length+'/'+a.length,v.length?pct(mean(v.map(r=>r.timeReach[ms].reached/r.total))):'미산출']);}
const pairedTimes=[];for(const ms of [30000,60000]){const a=rows.filter(r=>r.boundary==='charged'&&r.budget===20),keys=[...new Set(a.map(r=>r.site+'|'+r.entry+'|'+r.seed))],common=keys.map(k=>modes.map(mode=>a.find(r=>r.site+'|'+r.entry+'|'+r.seed===k&&r.mode===mode))).filter(group=>group.every(r=>r.timeReach[ms].valid));pairedTimes.push([ms/1000+'초',common.length+'/40',...modes.map((m,i)=>common.length?pct(mean(common.map(g=>g[i].timeReach[ms].reached/g[i].total))):'미산출')]);}
const featureChanged=validation.filter(r=>r.original_detail!==r.replica_detail).length;
const misses=collection.checks.filter(c=>!c.found||!c.text_equal||!c.signal);
let text=`# 실사이트 및 실제 DOM 복제본 비교 결과 — 2026-09-24

**최종 선택: FIFO 유지.** 이번 실험과 이전 합성 실험을 종합해도 운영 교체 관문을 통과한 후보가 없다. 새 알고리즘이 효율과 기존 위치 보존을 함께 개선할 것이라는 충분한 근거도 확보하지 못했으므로, 알고리즘을 계속 추가하는 세 번째 선택도 채택하지 않는다. FIFO의 수학적 최적성이나 실사이트 전체 광고 재현율을 입증한 결과는 아니다.

## 1. 실행 범위

사전 기준은 [real-replica-plan.md](real-replica-plan.md). FIFO/기존 문맥 Bandit/기존 URL 구조별 순환 FIFO의 코드는 변경하지 않았다. 운영 collector·worker·판정기 변경0, HCX/API 호출0, 토큰0. 공개 사이트 GET 관찰만 시행했고 광고는 로컬 복제본에만 넣었다. 원격 HTML/수집 근거/복제본은 Git 제외 ${root}에만 보관했다. push/공개 호스팅은 하지 않았다.

실제 시작점:
${capture.entries.map(e=>'- ['+e.id+']('+e.url+')').join('\n')}

두 기관의 네 시작점은 독립 사이트 네 개가 아니다. 실제 수집은 각 시작점×3정책×20시도이며 같은 URL은 한 번 수집한 응답을 공유했다. 원본 수집 기간 안에서도 사이트 내용 변경 가능성이 있으며 시점이 완전히 같은 스냅샷은 아니다. 정책별 전체 온라인 반복 시간을 측정한 것도 아니다.

## 2. 실제 탐색·수집에서 관찰한 문제

- 고유 요청 ${pages.length}개: 성공 ${ok.length}, 실패 ${pages.length-ok.length}. 실제 수집 벽시계 ${sec(capture.elapsed_ms)}초.
- 후보 ${diagnostics.candidates.toLocaleString()}개, 12,000자 초과 단위 ${diagnostics.long_candidates}개. 이번 진단은 운영 scan과 같이 allowLongText로 수집했다. 수집 실패로 단정하지 않으며, 분할 후 의미 보존은 이번 평가 범위가 아니다.
- JavaScript href ${diagnostics.js_links}회, fragment href ${diagnostics.fragment_links}회, onclick 보유 링크 ${diagnostics.handler_links}회(페이지 간 반복 포함). 이 숫자가 모두 고유 누락 페이지 수는 아니다. 클릭하지 않는 기본 탐색에서는 이러한 요소의 실제 목적지를 보장하지 못한다.
- iframe 요소 ${diagnostics.frames}회. 원본에서 프레임 내부 후보 ${ok.reduce((n,p)=>n+p.frame_candidates,0)}개를 수집했고 프레임 관련 미확인 기록 ${ok.reduce((n,p)=>n+p.frame_issues.length,0)}건이 남았다. 원본 collector는 기존 프레임 경계로 수집했으나 복제본에서는 외부 실행/프레임을 비활성화했다. iframe 일반화는 이 복제본 결과로 검증되지 않는다.
- 요청 URL과 최종 URL이 다른 리다이렉트 ${diagnostics.redirects.length}건. 요청 주소에 최종 렌더링 HTML을 동결했으며 복제 서버가 원본 HTTP 리다이렉트를 재현하지는 않는다. 따라서 별칭 URL의 최종 주소 중복 제거까지 원격과 동등하다는 증거는 아니다. 이 한계도 운영 교체를 막는 추가 근거다.
- 대기 미안정 ${diagnostics.unsettled}페이지. 안정화 통과는 클릭 후/늦은 댓글까지 전부 수집했다는 뜻이 아니다.
- 제한된 p/blockquote/comment 본문 fingerprint가 같으나 전체 후보 원문은 다른 그룹 ${collisionGroups.length}개. 문맥 Bandit의 새 detail 본문 보상은 실제 게시물의 신규성이나 광고 가능성과 동일하지 않다. 이러한 그룹을 무조건 중복 제거하면 안 된다.
- 원격 수집 profile과 동결 직전 DOM의 링크 순서 일치: ${diagnostics.profile_parity}. 차단 요청 기록 합계 ${diagnostics.blocked_requests}회는 중복 및 정적 리소스도 포함한다.

실패 내역:
${diagnostics.failures.map(p=>'- '+p.url+' — '+p.error.replace(/\n[\s\S]*/, '')).join('\n')}

정책별 진단(저장 응답 공유, 실제 광고 정답 없음):

${table(['시작점','정책','성공/시도','detail 판별 페이지','수집 후보','저장 수집시간 합계(초)','대기 URL'],liveRows.map(r=>[r.entry,names[r.mode],r.success+'/'+r.attempts,r.detail,r.candidates,sec(r.snapshot_ms),r.pending]))}

detail 수는 광고 도달률이 아니다. 시간에는 DOM 동결/디스크 저장 계측 부담이 포함되며 캐시 정책의 실행시간을 실제 전체 온라인 시간으로 해석하지 않는다. 이 진단은 페이지별 후보 상한20,000으로 읽었으며 운영 작업의 누적 후보10,000 상한을 적용한 완주 결과가 아니다. 부산 메인에서 문맥 Bandit의 후보57,144개 대 FIFO10,408개는 큰 판정 부담 차이다. 이런 차이 때문에 동일 페이지 예산의 이득만으로 운영 효율을 판단할 수 없다.

실제 수집기 구간 합계(모든 고유 시도, API0):

${table(['구간','초'],['navigation','readiness','extraction','context_setup','page_create','page_close','context_close'].map(k=>[k,sec(phases[k]||0)]))}

extraction에는 DOM/스타일/위치/프레임 추출과 후보 가공이 포함된다. page_close에는 이 실험의 동결 계측이 섞여 있으므로 순수 close 비용으로 인용하지 않는다. 벽시계와 구간 합계 차이에는 파일 저장과 실험 진행 제어도 들어간다.

## 3. 복제본과 정답

${table(['복제본','저장 성공 HTML','주입 광고','정상 주입 대조','미수집 경계 URL'],catalog.map(s=>[s.id,s.html,s.ads,s.normal_controls,s.boundaries]))}

원본 HTML의 태그·클래스·주소 경로와 쿼리·링크 순서를 보존하고 주요 계산 스타일을 인라인 고정했다. 스크립트/폼/외부 리소스는 비활성화했다. 실제 서버 기능이나 픽셀 단위 동일성을 주장하지 않는다. 각 페이지의 실제 내용 컨테이너 안에 제목/본문/댓글 중 한 개의 합성 위치를 추가하고, 광고가 아닌 페이지에도 같은 표면/위장 스타일의 정상 대조 문장을 넣었다. 이는 광고 표시와 DOM 역할의 완전한 상관을 피하기 위한 통제다. 원래 목록 제목을 광고 제목으로 바꾸거나 목록과 상세 내용을 동기화하지는 않았다.

주입 전후 detail 여부가 바뀐 페이지×배치 ${featureChanged}/${validation.length}개다. 이러한 합성 위치 추가도 문맥 정책에 영향을 줄 수 있어 실사이트 원형과 동일한 실험이라고 주장하지 않는다. 스크린샷 검토에서 이미지 미복제와 일부 메뉴·표 겹침도 확인했다. 탐색 링크 구조와 통제 위치의 수집을 검증한 자료이며 원본 좌표·스타일 전체를 보존한 렌더링 벤치마크는 아니다. 본문이 정상이라는 자동 라벨은 부여하지 않았다. 광고 배치 seed401/809를 결과 확인 전 고정했고, 선택에는 정책의 방문 순서를 사용하지 않았다. 원본 자료 자체가 세 정책의 수집 합집합이므로 수집 선택 편향은 남는다.

링크 순서5개×시작점4개×배치2개×정책3개로 주요 비교를 수행했다. 40회 조건을 40개 독립 사이트 표본으로 해석하지 않는다. 저장 밖 링크는 제거하지 않고 410 경계 응답으로 한 번의 시도 예산을 차감했다. 이는 실제 원격 HTTP410이나 정상 막다른 길을 의미하지 않는다. 경계의 실제 후속 링크는 알 수 없으므로 이 결과는 유한 저장 범위에 대한 스트레스 진단이다.

## 4. 전체 주입 광고 위치 도달률

${aggregateTable('charged')}

도달은 해당 광고가 주입된 페이지를 방문했다는 의미다. LLM 정탐/F1이 아니다. 시작점에서 연결되지 않은 주입 광고도 전체 분모에 남기고 별도 집계했다. FIFO의 기존 광고 손실은 신규 광고 이득과 상쇄하지 않았다.

시작점별 @20(배치 두 개 평균, 최저는 10개 조건의 관측 최저, 표준편차는 배치별 링크 순서 표준편차의 평균):

${table(['시작점','정책','평균','최저','순서 표준편차','FIFO 손실 실행'],perEntry)}

기관×시작점×배치 안의 링크 순서 표준편차를 평균하면 FIFO ${pct(mean(summary.perCell.filter(r=>r.mode==='fifo'&&r.budget===20).map(r=>r.sd)))}p, 문맥 Bandit ${pct(mean(summary.perCell.filter(r=>r.mode==='context-bandit'&&r.budget===20).map(r=>r.sd)))}p, URL 구조순환 ${pct(mean(summary.perCell.filter(r=>r.mode==='template-fifo'&&r.budget===20).map(r=>r.sd)))}p다. 이번 자료에서는 문맥 Bandit의 순서 민감도가 더 작았다. 미채택 이유를 막연히 변동성 증가라고 설명하지 않는다. 기관별 평균 회귀, 조건별 최저값 회귀, 기존 FIFO 위치 손실은 서로 다른 평가 축이다.

## 5. 미수집 경계를 제거한 보조 민감도 분석

${aggregateTable('closed')}

이 표는 저장 성공 HTML 사이의 링크만 남긴 유한 내부 그래프다. 운영 범위를 줄이자는 제안이 아니며 실사이트 전체 성능으로 외삽할 수 없다. 주요 charged 결과와 함께 비교하되 좋은 쪽만 선택하지 않는다.

## 6. 누락과 영역별 손익

${table(['정책','평균 도달 위치','발견 후 대기','주소 미발견'],modes.map(mode=>{const a=summary.aggregate.find(r=>r.mode===mode&&r.boundary==='charged'&&r.budget===20);return[names[mode],(a.mean*24).toFixed(2),a.waiting.toFixed(2),a.undiscovered.toFixed(2)];}))}

${table(['그룹',...modes.map(m=>names[m])],[...new Set(groupRows.map(r=>r.key))].map(key=>[key,...modes.map(m=>{const r=groupRows.find(r=>r.mode===m&&r.key===key);return r.total?pct(r.recall):'표본 없음';})]))}

깊이≥5 광고는 없으므로 깊은 영역 개선은 미검증이다. 사전 목표의 깊은 배치6개는 원본에 충분한 깊이가 없어 부산3개/대전0개이며, 부족분은 정책 순서와 무관한 hash 순서의 remainder에 배치했다. 여기서 부산의 deep 시나리오도 상대적으로 깊다는 뜻이며 시작점에 따라 3~4단계다. 기존 사이트의 링크를 인위적으로 긴 경로로 늘리지 않았다. 저장 범위 밖을 조사하지 않았으므로 주소 미발견 원인의 일부는 스냅샷 경계에 의해 검열된 것이다.

## 7. 시간 예산

${table(['시간 예산','정책','유효 조건','유효 부분의 도달률'],timeRows)}

각 URL의 원격 수집 계측시간을 합산한 대용 지표다. 첫 미수집 경계 전까지 해당 시간 예산을 충족한 조건만 유효하다. 정책마다 유효 조건이 다르면 평균을 직접 비교할 수 없다. 한 번의 측정이고 브라우저·수집/동결 부하가 섞여 있으므로 종단 지연 우위를 선언하지 않는다. 별도 호출량은0이다.

세 정책 모두 유효한 동일 조건으로 제한한 보조 비교:

${table(['예산','공통 조건',...modes.map(m=>names[m])],pairedTimes)}

60초 비교는 공통2조건뿐이라 채택 근거로 부족하다. 이 표 역시 수집시간 합계의 대용치이며 HCX 판정과 큐 계산 시간을 포함한 실제 종단 시간이 아니다.

최초 집계의 원격 URL 복원에서 로컬 포트가 남아 시간 조회가 실패하는 오류를 발견했다. 원본 rows.json을 보존하고 time-audit.cjs로 시간 필드만 재계산한 rows-audited.json을 위 표에 사용했다. 시간 외 모든 필드의 hash 일치를 확인했으며 정책·방문 순서·도달률·FIFO 손실·채택 관문은 바뀌지 않았다. 이를 정책 개선 재실험으로 세지 않는다.

## 8. 수집·무결성 검증

- 실제 복제 DOM 광고/정상 대조 ${collection.checks.length}곳을 운영 collector로 검사: ${collection.pass?'통과':'미통과'}, 누락/원문/신호 불일치 ${misses.length}곳. selector·분할 span 원문 결합·4종 signals를 확인했다. signals는 최종 기법/불법광고 판정과 다르다.
- 모든 링크 순서의 중복 제거 ${summary.integrity.dedup}회, 10→20 직렬화 재개 ${summary.integrity.resume}회, 예산 접두부 ${summary.integrity.prefix}회 통과.
- 원래 링크 순서에서 전체 charged 방문 집합 ${summary.integrity.full_set}회 통과. 다른 순서의 전체 순회를 모두 반복한 것은 아니다.
- 독립 집계 ${audit.recounted_rows}행 재계산 및 실제 core runner ${audit.core_checks.length}조건 중단/재개 일치. LLM 후보를 전달하지 않은 실행 제어 검사다.
- 원격에서 기록한 요청/최종 URL을 그대로 쓰는 별도 redirect-audit 12조건도 통과했다. 리다이렉트 시도21회가 포함됐고 최종 페이지 중복0, 연속 실행/10→20 재개 순서가 같았다. 이는 운영 core의 주소 처리 검증이며, 동결 복제 서버의 리다이렉트 미재현 한계를 없애지는 않는다.
- 원본/정책/평가 입력 해시 실행 전후 대조. 단위 검사에서 발견된 라벨 부족분 채우기 오류는 점수 산출 전에 수정했으며 결과에 맞춘 정책 변경은 없다.

## 9. 채택 판단

${table(['후보','조건별 평균','FIFO 위치 보존','기관별 +5%p','최저값','경계≤10%','무결성'],summary.gates.map(g=>[names[g.mode],...['cell_mean','retained','institution_gain','worst','boundary','integrity'].map(k=>g.checks[k]?'통과':'실패')]))}

이전 v5 합성 비교에서도 후보들은 50페이지에서 기존 FIFO 광고 위치를 잃었다. 이번의 실제 DOM 복제본 결과와 합쳐 운영을 교체할 근거는 확보되지 않았다. 서로 다른 예산/자료의 점수를 하나의 평균으로 합치지 않는다.

새 알고리즘을 제안하지 않는 이유는 실패 원인에 수집 경계, JS 이동, 보상에 쓰이는 본문 표현, 광고 위치를 사전에 모르는 탐색의 상충이 섞여 있기 때문이다. 다른 우선순위 규칙이 어떤 미방문 페이지에 광고가 있는지 알아낼 수 있다고 예상할 근거는 없다. 관찰한 주소/템플릿에 맞춘 가중치 조정은 과적합 위험이 크다. 새로운 알고리즘의 우월성을 가정해 실험을 늘리기보다 FIFO를 유지하는 결론이 현재 증거에 맞다.

실사이트 실제 광고의 전체 정답·정밀도/F1, JS 클릭/로그인/늦은 댓글, 복제하지 않은 프레임, 종단 HCX 판정과 비용은 미검증이다. 현재 알려진 의미/기법 판정 오류도 해결됐다고 주장하지 않는다.

## 재현

- 원격 수집: node agent/experiments/real-replica.cjs capture <새 runtime 경로>
- 저장 DOM 준비: node agent/experiments/real-replica-eval.cjs prepare <경로>
- 정책 비교: node agent/experiments/real-replica-eval.cjs run <경로>
- 수집 검증: node agent/experiments/real-replica-eval.cjs verify <경로>
- 기본 검사: node agent/experiments/real-replica.test.cjs

결과 파일: capture.json, live-diagnostics.json, replica-manifest.json, replica-catalog.json, replicas/*.json, rows.json, runs.json, summary.json, collector-checks.json, independent-audit.json. 정책 재생은 원격 요청/LLM 없이 저장 자료만 사용한다. 완료된 결과를 덮어쓰지 않는다.
`;
fs.writeFileSync('docs/real-replica-report.md',text);console.log(JSON.stringify({report:'docs/real-replica-report.md',diagnostics:{pages:diagnostics.pages,success:diagnostics.success,candidates:diagnostics.candidates},aggregate:summary.aggregate.filter(r=>r.boundary==='charged'),gates:summary.gates,collection:collection.pass}));
